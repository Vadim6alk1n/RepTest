# lesson9

## synchronizing Code

### Concepts

#### Atomicity

Хотя многие это знают, считаю необходимым напомнить, что на некоторых платформах некоторые операции записи могут оказаться неатомарными. То есть, пока идёт запись значения одним потоком, другой поток может увидеть какое-то промежуточное состояние. За примером далеко ходить не нужно — записи тех же long и double, если они не объявлены как volatile, не обязаны быть атомарными и на многих платформах записываются в две операции: старшие и младшие 32 бита отдельно.

#### Visibility

В старой JMM у каждого из запущенных потоков был свой кеш (working memory), в котором хранились некоторые состояния объектов, которыми этот поток манипулировал. При некоторых условиях кеш синхронизировался с основной памятью (main memory), но тем не менее существенную часть времени значения в основной памяти и в кеше могли расходиться.

В новой модели памяти от такой концепции отказались, потому что то, где именно хранится значение, вообще никому не интересно. Важно лишь то, при каких условиях один поток видит изменения, выполненные другим потоком. Кроме того, железо и без того достаточно умно, чтобы что-то кешировать, складывать в регистры и вытворять прочие операции.

Важно отметить, что, в отличие от того же C++, «из воздуха» (out-of-thin-air) значения никогда не берутся: для любой переменной справедливо, что значение, наблюдаемое потоком, либо было ранее ей присвоено, либо является значением по умолчанию.

#### Reordering

Процессоры проявляют невероятную проворность в оптимизации исполнения инструкций. В этом им также помогает компилятор и JIT. Одним из примечательных эффектов может оказаться то, что действия, выполненные одним потоком, другой поток увидит в другом порядке.

```java
public class ReorderingSample {
    boolean first = false;
    boolean second = false;

    void setValues() {
        first = true;
        second = true;
    }

    void checkValues() {
        while(!second);
        assert first;
    }
}
```

И в этом коде из одного потока вызывается метод checkValues, а из другого потока — setValues. Казалось бы, код должен выполняться без проблем, ведь полю second значение true присваивается позже, чем полю first, и потому когда (точнее, если) мы видим, что, второе поле истинно, то и первое тоже должно быть таким. Но не тут-то было.

#### volatile & synchronized

synchronized имеет два важных момента: это гарантия того, что только один поток выполняет секцию кода в один момент времени (взаимоисключение или mutex), и также гарантия того, что данные, изменённые одним потоком, будут видны всем другим потокам (видимость изменений).

volatile проще, нежели синхронизация и подходит только для контроля доступа к одиночному экземпляру или переменной примитивного типа: int, boolean... Когда переменная объявлена как volatile, любая запись её будет осуществляться прямо в память, минуя кеш. Также как и считываться будет прямо из памяти, а не из всевозможного кеша. Это значит, что все потоки будут "видеть" одно и то же значение переменной одновременно.

Если переменная объявлена как volatile, это означает, что ожидается её изменение несколькими потоками. Естественно, вы думаете, что JRE наложит какие-то формы синхронизации для volatile переменных. Хорошо это или плохо, JRE неявно обеспечивает синхронизацию при доступе к volatile переменным, но с одной очень большой оговоркой: чтение volatile переменных синхронизировано и запись в volatile переменные синхронизирована, а неатомарные операции – нет.
Что означает, что следующий код не безопасен для потоков:
```
myVolatileVar++;
```

Этот код также может быть записан следующим образом:

```
int temp = 0;
synchronize( myVolatileVar ) {
  temp = myVolatileVar;
}

temp++;

synchronize( myVolatileVar ) {
  myVolatileVar = temp;
}
```


Другими словами, если volatile переменная обновляется неявно, то есть значение читается, измененяется, а затем присваивается как новое, результат будет не-потокобезопасным между двумя синхронными операциями. Вы можете выбирать, следует ли использовать синхронизацию или рассчитывать на поддержку JRE автоматической синхронизации volatile переменных. Наилучший подход зависит от вашего случая: если присвоенное значение volatile переменной зависит от её текущего значения (например, во время операции инкремента), то нужно использовать синхронизацию, если вы хотите, чтобы операция была потокобезопасной.

--------

### Fred and Lucy - race condition

This problem is known as a "race condition" (Состояние гонки), where multiple threads can access the same resource (typically an object's instance variables), and can produce corrupted data if one thread "races in" too quickly before an operation that should be "atomic" has completed.

```java
volatile int x;

// Thread 1:
while (!stop)
{
  x++;
}

// Thread 2:
while (!stop)
{
  if (x%2 == 0)
    System.out.println("x=" + x);
}

```

### Solve - local copy

```java
// Thread 2:
while (!stop)
{
  int cached_x = x;
  if (cached_x%2 == 0)
    System.out.println("x=" + cached_x);
}
```

### Solve - synchronizing

```java
// Thread 1:
while (!stop)
{
  synchronized(SomeObject)
  {
    x++;
  }
}
```

```java
// Thread 2:
while (!stop)
{
  synchronized(SomeObject)
  {
    if (x%2 == 0)
      System.out.println("x=" + x);
  }
}
```

### Solve - combine

Предположим, что переменных — две, а во втором потоке вместо System.out.println стоит более сложная обработка.
В этом случае оба метода неудовлетворительны: первый — потому что одна переменная может измениться, пока копируется другая; второй — потому что засинхронизирован слишком большой объём кода.

```java
// Thread 1:
while (!stop)
{
  synchronized(SomeObject)
  {
    x1++;
    x2++;
  }
}

// Thread 2:
while (!stop)
{
  int cached_x1, cached_x2;
  synchronized (SomeObject)
  {
    cached_x1 = x1;
    cached_x2 = x2;
  }
  if ((cached_x1 + cached_x2)%100 == 0)
    DoSomethingComplicated(cached_x1, cached_x2);

}
```


## synchronization and Locks

How does synchronization work? With locks.

- Only methods (or blocks) can be synchronized, not variables or classes.
- Each object has just one lock.
- Not all methods in a class need to be synchronized. A class can have both synchronized and non-synchronized methods.
- If two threads are about to execute a synchronized method in a class, and both threads are using the same instance of the class to invoke the method, only one thread at a time will be able to execute the method. The other thread will need to wait until the first one finishes its method call. In other words, once a thread acquires the lock on an object, no other thread can enter any of the synchronized methods in that class (for that object).
- If a class has both synchronized and non-synchronized methods, multiple threads can still access the class's non-synchronized methods! If you have methods that don't access the data you're trying to protect, then you don't need to synchronize them. Synchronization can cause a hit in some cases (or even deadlock if used incorrectly), so you should be careful not to overuse it.
- If a thread goes to sleep, it holds any locks it has—it doesn't release them.
- A thread can acquire more than one lock. For example, a thread can enter a synchronized method, thus acquiring a lock, and then immediately invoke a synchronized method on a different object, thus acquiring that lock as well. As the stack unwinds, locks are released again. Also, if a thread acquires a lock and then attempts to call a synchronized method on that same object, no problem. The JVM knows that this thread already has the lock for this object, so the thread is free to call other synchronized methods on the same object, using the lock the thread already has.
- You can synchronize a block of code rather than a method.

```java
class SyncTest {
  public void doStuff() {
    System.out.println("not synchronized");
    synchronized(this) {
      System.out.println("synchronized");
    }
  }
}
```

When you synchronize a method, the object used to invoke the method is the object whose lock must be acquired. But when you synchronize a block of code, you specify which object's lock you want to use as the lock, so you could, for example, use some third-party object as the lock for this piece of code. That gives you the ability to have more than one lock for code synchronization within a single object.

Or you can synchronize on the current instance (this) as in the code above. Since that's the same instance that synchronized methods lock on, it means that you could always replace a synchronized method with a non-synchronized method containing a synchronized block.

```java
public synchronized void doStuff() {
      System.out.println("synchronized");
}
```

```java
 public void doStuff() {
      synchronized(this) {
          System.out.println("synchronized");
      }
}
```

### static Methods?

static methods can be synchronized. There is only one copy of the static data you're trying to protect, so you only need one lock per class to synchronize static methods—a lock for the whole class.

```java
public static synchronized int getCount() {
    return count;
}
```

```java
public static int getCount() {
    synchronized(MyClass.class) {
        return count;
    }
}
```

Wait—what's that MyClass.class thing? That's called a class literal. It's a special feature in the Java language that tells the compiler (who tells the JVM): go and find me the instance of Class that represents the class called MyClass. You can also do this with the following code:

```java
public static void classMethod() {
  Class cl = Class.forName("MyClass");
  synchronized (cl) {
    // do stuff
  }
}
```
-----

What Happens if a thread Can't Get the Lock?


------

### thread Deadlock

```java
public class DeadlockRisk {
  private static class Resource {}
  public int value;
  private Resource resourceA = new Resource();
  private Resource resourceB = new Resource();
  public int read() {
    synchronized(resourceA) { // May deadlock here
      synchronized(resourceB) {
        return resourceB.value + resourceA.value;
      }
    }
  }

  public void write(int a, int b) {
    synchronized(resourceB) { // May deadlock here
      synchronized(resourceA) {
        resourceA.value = a;
        resourceB.value = b;
      }
    }
  }
}
```

## thread interaction

The last thing we need to look at is how threads can interact with one another to communicate about—among other things—their locking status. The Object class has three methods, wait(), notify(), and notifyAll()that help threads communicate about the status of an event that the threads care about. For example, if one thread is a mail-delivery thread and one thread is a mail-processor thread, the mail-processor thread has to keep checking to see if there's any mail to process. Using the wait and notify mechanism, the mail-processor thread could check for mail, and if it doesn't find any it can say, "Hey, I'm not going to waste my time checking for mail every two seconds. I'm going to go hang out, and when the mail deliverer puts something in the mailbox, have him notify me so I can go back to runnable and do some work." In other words, using wait() and notify() lets one thread put itself into a "waiting room" until some other thread notifies it that there's a reason to come back out.

One key point to remember about wait/notify is this:

**wait(), notify(), and notifyAll() must be called from within a synchronized context! A thread can't invoke a wait or notify method on an object unless it owns  that object's lock.**

Think of a computer-controlled machine that cuts pieces of fabric into different shapes and an application that allows users to specify the shape to cut. The current version of the application has one thread, which loops, first asking the user for instructions, and then directs the hardware to cut the requested shape:

```java
public void run(){
  while(true){
    // Get shape from user
    // Calculate machine steps from shape
    // Send steps to hardware
  }
}
```

This design is not optimal because the user can't do anything while the machine is busy and while there are other shapes to define. We need to improve the situation.
A simple solution is to separate the processes into two different threads, one of them interacting with the user and another managing the hardware. The user thread sends the instructions to the hardware thread and then goes back to interacting with the user immediately. The hardware thread receives the instructions from the user thread and starts directing the machine immediately. Both threads use a common object to communicate, which holds the current design being processed.
The following pseudocode shows this design:

```java
public void userLoop(){
 while(true){
    // Get shape from user
    // Calculate machine steps from shape
    // Modify common object with new machine steps
  }
}

public void hardwareLoop(){
 while(true){
    // Get steps from common object
    // Send steps to hardware
 }
}

```

The problem now is to get the hardware thread to process the machine steps as soon as they are available. Also, the user thread should not modify them until they have all been sent to the hardware.

```java
class ThreadA {
public static void main(String [] args) {
   ThreadB b = new ThreadB();
   b.start();
   synchronized(b) {
      try {
        System.out.println("Waiting for b to complete...");
        b.wait();
      } catch (InterruptedException e) {}
      System.out.println("Total is: " + b.total);
    }
  }
}

class ThreadB extends Thread {
  int total;

  public void run() {
    synchronized(this) {
      for(int i=0;i<100;i++) {
         total += i;
      }
      notify();
    }
  }
}
```

This program contains two objects with threads: ThreadA contains the main thread and ThreadB has a thread that calculates the sum of all numbers from 0 through 99. As soon as calls the start() method, ThreadA will continue with the next line of code in its own class, which means it could get to System.out before ThreadB has finished the calculation. To prevent this, we use the wait() method.
